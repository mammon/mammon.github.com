This is a quick setup for putting HIEW and Qedit in the context menu of all files 
(meaning: you right click any file, you get options for Hiew and QuickEdit). Copy 
all of the files except this readme and the .reg file to c:\windows. Run the .reg 
file from anywhere to patch the registry. There, you're done...

OF COURSE
You can modify the locations and the reg patch, etc...

_m