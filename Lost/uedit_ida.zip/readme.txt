Syntax highlighting for IDA Scripts in UltraEdit 

Makes .idc files much better readable and prevents you from using reserved words as names or variables.

Install Instructions:

- Unpack idawrds.txt to a temporary directory
- Open it with Ultraedit
  (The original Ultraedit wordfile contains syntax highlighting for 5 languages, so I configured idc as language 6.
   If you have more or less languages, change the "/L6" at the start of idawrds.txt to the appropiate number.)
- Open wordfile.txt in the Ultraedit directory
- copy idawrds.txt and paste it at the end of wordfile.txt, save
- close Ultraedit, delete idawrds.txt.

You can customise the colors with Advanced / Configuration / Syntax Highlighting
Choose IDC-Script as language in the scrolldown box, check "Enable syntax colouring"
Colour 1 and 2 are common C words, colour 3 are words special to IDA, colour 4 are operators and colour 5 are the braces.

Cephren 10/15/98
