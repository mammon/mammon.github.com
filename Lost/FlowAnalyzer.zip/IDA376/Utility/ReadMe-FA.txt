So, here it is...an advance copy.

There are four other files in the zip file that you have undoubtedly noticed already. The IDC file is the "preparation" script: it creates a call trace that is used by the EXE file. The two .fdb files are sample 
outputs of Notepad's WinMain and Start functions, set to trace 3 levels 
apiece; they will load directly into the EXE without using IDA.

Best, for the moment, to limit the IDC file to interesting functions or to disable the Jmp/Sub parsing (which makes it not-very-recursive) ...until the "real version" that will handle straight assembly files is produced.

The EXE has one purpose: code browsing. It uses the explorer tree-style  interface, allows you to rename/browse code, etc. I recommend running the IDC script and saving a .LST file of the program you are working on, then running FlowAnalyzer.exe and loading both the .fdb file and the .lst file. Then browse away...

Many more features are planned, any input is welcome. See the About box for the To-Do's.

_m