#!/usr/bin/perl
# ---- srch.pl keyword string -----
use Socket;
# ---- script constants ----
$port = 80;
$sitelist = 'sites.lst';
@hits = ();
@keywds = @ARGV;
# ---- cycle through URLs ----
open(SITEFILE, $sitelist) || die "File sites.lst is missing!"; 
@URLS = <SITEFILE>;
close(SITEFILE);
foreach $url (@URLS) {
  $url =~ s/\n//;
  ($url, $loc) = split(/\//, $url);
  $loc = "/$loc";
#  print "$url\n"; print "$loc\n"; # debug output
  $IPAddr = inet_aton($url) || next; #print "No IP Address for $url!";
  $SockAddr = sockaddr_in($port, $IPAddr);
  socket( SOCK, PF_INET, SOCK_STREAM, 0) || next; #print "Cannot create socket";
  connect( SOCK, $SockAddr) || next; # print "Cannot connect to $url";
  print "Sending to $url\n";
  send( SOCK, "GET $loc \r\n", 0);
  @UrlSrc = <SOCK>;
  $UrlSrc = join( ' ', @UrlSrc);
  close(SOCK);
  foreach $keywd (@keywds){
    #if match .. if MATCHFOUND next else add
    if ($UrlSrc =~ /$keywd/){
       #print "$keywd found in $url\n";
       push(@hits, $url);
    }
  }
}
foreach (@hits) {
  print;
}
exit;
