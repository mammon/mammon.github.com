#!/usr/bin/perl
use Socket;
$port = 80;
$remote = "www.yahoo.com";
$iaddr = inet_aton($remote);
$paddr = sockaddr_in($port, $iaddr);
socket( Sock, PF_INET, SOCK_STREAM, 0) || die "Can't create Socket";
connect(Sock, $paddr) || die "Can't connect socket"; 
send(Sock, "GET /\r\n",0);
while ($line =  <Sock> )
{
 print $line;
}
close(Sock);
exit;
